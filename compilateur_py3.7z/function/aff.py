def aff(wl):
    print ("aff")

    
