def load_function():
    import function.aff 
    from function import aff
