def decomp(tl , decop):
    f = tl.replace(decop,'')
    return f

